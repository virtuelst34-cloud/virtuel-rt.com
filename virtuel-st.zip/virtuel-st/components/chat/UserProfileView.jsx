import React from 'react';
import { useChat } from '@/lib/ChatContext';
import Avatar from './Avatar';
import DiamondBadge from './DiamondBadge';
import { getBadgeForLevel, getUnlockedBadges } from '@/lib/diamondBadges';
import { X, MessageSquare, UserX, Flame, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

// Fiche profil en lecture seule d'un autre utilisateur
export default function UserProfileView({ targetName, onClose, onOpenDM }) {
  const { profiles, user, blockUser, reportMessage, isBlocked } = useChat();
  const target = profiles[targetName] || { name: targetName, avatar: 'av1', initials: targetName.slice(0, 2).toUpperCase(), level: 1, xp: 0 };

  const lvl      = target.level || 1;
  const badge    = getBadgeForLevel(lvl);
  const unlocked = getUnlockedBadges(lvl);
  const blocked  = isBlocked(targetName);

  const handleBlock = () => { blockUser(targetName); onClose(); };
  const handleDM    = () => { onClose(); onOpenDM?.(targetName); };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[2000]" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl w-[360px] max-w-[95vw] overflow-hidden shadow-[0_24px_80px_rgba(0,0,0,0.6)]"
        onClick={e => e.stopPropagation()}>

        {/* Banner */}
        <div className="h-16 relative" style={{ background: `linear-gradient(135deg, ${badge.color}22, transparent)` }}>
          <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(236,72,153,0.1))' }} />
          <button onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-lg bg-black/30 text-white/60 hover:text-white hover:bg-black/50 transition-colors">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="px-5 pb-5">
          {/* Avatar + nom */}
          <div className="-mt-7 mb-4 flex items-end justify-between">
            <Avatar avatarClass={target.avatar} initials={target.initials} size="lg" />
            <div className="flex gap-2 mb-1">
              {user?.name !== targetName && (
                <>
                  <button onClick={handleDM}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/15 border border-primary/30 text-primary text-xs font-medium hover:bg-primary/25 transition-colors">
                    <MessageSquare className="w-3.5 h-3.5" /> Message
                  </button>
                  {!blocked ? (
                    <button onClick={handleBlock}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-medium hover:bg-red-500/20 transition-colors">
                      <UserX className="w-3.5 h-3.5" /> Bloquer
                    </button>
                  ) : (
                    <span className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/5 border border-border text-muted-foreground/50 text-xs">
                      <UserX className="w-3.5 h-3.5" /> Bloqué
                    </span>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Nom + badge */}
          <div className="mb-3">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-[17px] font-bold text-foreground">{target.name}</span>
              <DiamondBadge level={lvl} size="sm" showLabel />
            </div>
            {target.joinedAt && (
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground/50">
                <Calendar className="w-3 h-3" />
                Membre depuis {format(new Date(target.joinedAt), 'd MMMM yyyy', { locale: fr })}
              </div>
            )}
          </div>

          {/* Bio */}
          <div className="mb-4 bg-secondary border border-border rounded-xl px-3 py-2.5">
            <div className="text-[10px] text-muted-foreground/50 uppercase tracking-widest mb-1">Bio</div>
            <p className="text-sm text-muted-foreground/80 italic">
              {target.bio || 'Cet utilisateur n\'a pas encore de bio.'}
            </p>
          </div>

          {/* XP & Niveau */}
          <div className="bg-secondary border border-border rounded-xl p-3 mb-4">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-xs font-semibold text-foreground">Niveau {lvl}</span>
              </div>
              <span className="text-[11px] text-muted-foreground/50">{(target.xp || 0).toLocaleString()} XP</span>
            </div>
            <div className="bg-background rounded-full h-1.5 overflow-hidden">
              <div className="h-full rounded-full xp-gradient" style={{ width: `${Math.min(100, ((target.xp || 0) / (lvl * lvl * 500)) * 100)}%` }} />
            </div>
          </div>

          {/* Badges */}
          {unlocked.length > 0 && (
            <div>
              <div className="text-[10px] text-muted-foreground/50 uppercase tracking-widest mb-2">
                Badges débloqués ({unlocked.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {unlocked.map(b => (
                  <span key={b.id}
                    className="flex items-center gap-2 border rounded-xl px-3 py-1.5"
                    style={{ borderColor: b.color + '44', background: b.color + '12' }}>
                    <DiamondBadge level={b.minLevel} size="sm" />
                    <span className="text-[11px] font-semibold" style={{ color: b.color }}>{b.label}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
